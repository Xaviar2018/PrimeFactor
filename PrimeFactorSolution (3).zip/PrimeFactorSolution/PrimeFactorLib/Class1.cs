﻿namespace PrimeFactorLib;

public class Class1
{

}
